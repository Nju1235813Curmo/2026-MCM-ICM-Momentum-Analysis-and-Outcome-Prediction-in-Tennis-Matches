# -*- coding: utf-8 -*-
"""
序列长度敏感性分析：
seq_len = [5, 10, 15, 20, 30, 40]
基于 BiLSTM（最佳模型）对比 AUC / F1 / MAE / RMSE
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import f1_score, roc_auc_score, mean_absolute_error, mean_squared_error
import matplotlib.pyplot as plt


# ===========================
# Dataset
# ===========================
class TennisDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ===========================
# BiLSTM
# ===========================
class ImprovedLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, num_layers=1, dropout=0.3):
        super().__init__()
        self.lstm = nn.LSTM(
            input_dim, hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout,
            bidirectional=True
        )
        self.norm = nn.LayerNorm(hidden_dim * 2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.norm(out[:, -1, :])
        out = self.fc(out)
        return self.sigmoid(out).squeeze(-1)


# ===========================
# 构造序列
# ===========================
def build_sequences(df, seq_len=20, label_col="p1_won"):
    X_list, y_list = [], []

    for _, match_df in df.groupby("match_id"):
        match_df = match_df.sort_values("point_no")

        # 特征矩阵（自动忽略已不存在的列）
        X_vals = match_df.drop(columns=[label_col], errors="ignore").values

        # 标签
        y_vals = match_df[label_col].values

        for i in range(seq_len, len(match_df)):
            X_list.append(X_vals[i - seq_len:i])
            y_list.append(y_vals[i])

    return np.array(X_list), np.array(y_list)


# ===========================
# 按 match 划分 train / test
# ===========================
def split_by_match(df):
    matches = df["match_id"].unique()
    np.random.shuffle(matches)

    split_idx = int(len(matches) * 0.7)
    train_m = matches[:split_idx]
    test_m = matches[split_idx:]

    return (
        df[df.match_id.isin(train_m)],
        df[df.match_id.isin(test_m)],
    )


# ===========================
# 训练 + 评估
# ===========================
def train_and_evaluate(seq_len, df_train, df_test, input_dim, device):

    X_train, y_train = build_sequences(df_train, seq_len)
    X_test, y_test = build_sequences(df_test, seq_len)

    train_loader = DataLoader(TennisDataset(X_train, y_train), batch_size=64, shuffle=True)
    test_loader = DataLoader(TennisDataset(X_test, y_test), batch_size=64)

    model = ImprovedLSTM(input_dim).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)
    criterion = nn.BCELoss()

    # 训练 5 epoch（用于敏感性分析）
    for epoch in range(5):
        model.train()
        for Xb, yb in train_loader:
            Xb, yb = Xb.to(device), yb.to(device)
            optimizer.zero_grad()
            preds = model(Xb)
            loss = criterion(preds, yb)
            loss.backward()
            optimizer.step()

    # 测试
    model.eval()
    preds = []
    with torch.no_grad():
        for Xb, _ in test_loader:
            preds.append(model(Xb.to(device)).cpu().numpy())

    preds = np.concatenate(preds)
    y_true = y_test

    mae = mean_absolute_error(y_true, preds)
    rmse = np.sqrt(mean_squared_error(y_true, preds))
    f1 = f1_score(y_true, (preds >= 0.5).astype(int))
    auc = roc_auc_score(y_true, preds)

    return mae, rmse, f1, auc


# ===========================
# Main
# ===========================
def main():

    df = pd.read_csv("train_features.csv")

    # ==== Step 1: 修复三个字符串类别特征 ====
    cat_cols = ["serve_width", "serve_depth", "return_depth"]
    for col in cat_cols:
        df[col] = df[col].astype("category").cat.codes

    # ==== Step 2: 修复可能存在的其他 object 列（强制全部分类编码）====
    for col in df.columns:
        if df[col].dtype == "object":   # 再次检查
            df[col] = df[col].astype("category").cat.codes

    # ==== Step 3: 填补所有 NaN ====
    df = df.fillna(0)

    # ==== Step 4: 构造最终标签 ====
    df["p1_won"] = (df["point_victor"] == 1).astype(int)
    df = df.drop(columns=["point_victor"])

    # ==== Step 5: 重新检查是否还有 object ====
    print("Remaining object cols:", df.select_dtypes(include="object").columns.tolist())

    # ==== Step 6: 输入维度 ====
    input_dim = df.drop(columns=["p1_won"]).shape[1]


    device = "cuda" if torch.cuda.is_available() else "cpu"

    df_train, df_test = split_by_match(df)

    seq_lens = [5, 10, 15, 20, 30, 40]

    results = {"seq_len": [], "MAE": [], "RMSE": [], "F1": [], "AUC": []}

    for sl in seq_lens:
        print(f"\n=== seq_len = {sl} ===")
        mae, rmse, f1, auc = train_and_evaluate(sl, df_train, df_test, input_dim, device)

        results["seq_len"].append(sl)
        results["MAE"].append(mae)
        results["RMSE"].append(rmse)
        results["F1"].append(f1)
        results["AUC"].append(auc)

        print(f"MAE={mae:.4f} RMSE={rmse:.4f} F1={f1:.4f} AUC={auc:.4f}")

    results = pd.DataFrame(results)
    results.to_csv("seq_len_sensitivity.csv", index=False, encoding="utf-8-sig")

    # 绘图：AUC曲线
    plt.figure(figsize=(10, 5))
    plt.plot(results["seq_len"], results["AUC"], marker="o")
    plt.xlabel("Sequence Length")
    plt.ylabel("AUC")
    plt.title("AUC vs Sequence Length")
    plt.grid(True)
    plt.savefig("auc_vs_seq_len.png", dpi=150)

    # 绘图：F1曲线
    plt.figure(figsize=(10, 5))
    plt.plot(results["seq_len"], results["F1"], marker="o", color="orange")
    plt.xlabel("Sequence Length")
    plt.ylabel("F1-score")
    plt.title("F1 vs Sequence Length")
    plt.grid(True)
    plt.savefig("f1_vs_seq_len.png", dpi=150)

    print("\n实验完成！已生成：")
    print("seq_len_sensitivity.csv")
    print("auc_vs_seq_len.png")
    print("f1_vs_seq_len.png")


if __name__ == "__main__":
    main()
