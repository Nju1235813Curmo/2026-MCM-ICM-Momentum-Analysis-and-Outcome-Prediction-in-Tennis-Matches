# -*- coding: utf-8 -*-
"""
网球“势头”分析 & 下一局预测脚本

功能：
1. 基于逐分数据训练 GRU 模型（seq_len=20）
2. 为每一分生成预测概率，画出某场比赛的势头曲线（momentum curve）
3. 检测该场比赛的势头反转点（momentum shifts）
4. 用逐分预测概率聚合到 game 级别，评估下一局胜负预测能力
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt


# ============================
# 配置
# ============================
SEQ_LEN = 20            # 序列长度
BATCH_SIZE = 64
EPOCHS = 15             # 训练轮数（可适当调大）
MOMENTUM_WINDOW = 8     # 动量平滑窗口
MOMENTUM_THRESHOLD = 0.03  # 势头反转阈值（越大越“严格”）


# ============================
# 数据集封装
# ============================
class TennisDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ============================
# GRU 模型（双向，和你之前风格一致）
# ============================
class GRUModel(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2, dropout=0.5):
        super().__init__()
        self.gru = nn.GRU(
            input_dim,
            hidden_dim,
            num_layers=num_layers,
            dropout=dropout,
            batch_first=True,
            bidirectional=True
        )
        self.norm = nn.LayerNorm(hidden_dim * 2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_dim, 1)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, _ = self.gru(x)
        out = self.norm(out[:, -1, :])
        out = self.fc(out)
        return self.sigmoid(out).squeeze(-1)


# ============================
# 构造序列数据
# ============================
def build_sequences(df, seq_len, feature_cols, label_col="p1_won"):
    X_list, y_list = [], []

    # 按比赛构建序列
    for _, match_df in df.groupby("match_id"):
        match_df = match_df.sort_values("point_no")
        X_vals = match_df[feature_cols].values
        y_vals = match_df[label_col].values

        for i in range(seq_len, len(match_df)):
            X_list.append(X_vals[i - seq_len:i])
            y_list.append(y_vals[i])

    return np.array(X_list), np.array(y_list)


# ============================
# 训练和评估（逐分）
# ============================
def train_gru_model(X_train, y_train, X_val, y_val, input_dim, device):
    model = GRUModel(input_dim).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)
    criterion = nn.BCELoss()

    train_loader = DataLoader(TennisDataset(X_train, y_train), batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(TennisDataset(X_val, y_val), batch_size=BATCH_SIZE, shuffle=False)

    for epoch in range(1, EPOCHS + 1):
        # 训练
        model.train()
        total_loss = 0
        for Xb, yb in train_loader:
            Xb, yb = Xb.to(device), yb.to(device)
            optimizer.zero_grad()
            preds = model(Xb)
            loss = criterion(preds, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(Xb)
        train_loss = total_loss / len(train_loader.dataset)

        # 验证
        model.eval()
        total_loss = 0
        correct = 0
        with torch.no_grad():
            for Xb, yb in val_loader:
                Xb, yb = Xb.to(device), yb.to(device)
                preds = model(Xb)
                loss = criterion(preds, yb)
                total_loss += loss.item() * len(Xb)
                pred_label = (preds >= 0.5).float()
                correct += (pred_label == yb).sum().item()
        val_loss = total_loss / len(val_loader.dataset)
        val_acc = correct / len(val_loader.dataset)

        print(f"[Epoch {epoch:02d}] Train {train_loss:.4f} | Val {val_loss:.4f} | Val Acc {val_acc:.4f}")

    return model


# ============================
# 为每一分生成预测概率
# ============================
def add_point_predictions(df, model, feature_cols, seq_len, device):
    df = df.copy()
    df["p1_win_prob"] = np.nan

    model.eval()
    with torch.no_grad():
        for mid, match_df in df.groupby("match_id"):
            match_df = match_df.sort_values("point_no").copy()
            X_vals = match_df[feature_cols].values

            probs = [np.nan] * len(match_df)

            for i in range(seq_len, len(match_df)):
                seq = X_vals[i - seq_len:i]
                seq_t = torch.tensor(seq, dtype=torch.float32, device=device).unsqueeze(0)
                p = model(seq_t).item()
                probs[i] = p

            match_df["p1_win_prob"] = probs
            # 写回原 df
            df.loc[match_df.index, "p1_win_prob"] = match_df["p1_win_prob"]

    return df


# ============================
# 动量曲线 & 势头反转点
# ============================
def analyze_momentum_for_match(df, match_id, window=MOMENTUM_WINDOW, threshold=MOMENTUM_THRESHOLD):
    mdf = df[df["match_id"] == match_id].sort_values("point_no").copy()

    # 只保留有预测概率的点
    mdf = mdf[~mdf["p1_win_prob"].isna()].copy()
    if mdf.empty:
        print(f"Match {match_id}: 没有足够序列生成预测概率")
        return

    # 动量曲线（滚动平均）
    mdf["momentum_score"] = mdf["p1_win_prob"].rolling(window=window, min_periods=1).mean()

    # 保存 CSV
    out_csv = f"momentum_match_{match_id}.csv"
    mdf.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print(f"该比赛逐分动量数据已保存：{out_csv}")

    # 画图
    plt.figure(figsize=(10, 5))
    plt.plot(mdf["point_no"], mdf["momentum_score"], label="Momentum (rolling prob)")
    plt.axhline(0.5, color="gray", linestyle="--", linewidth=1, label="50% baseline")
    plt.xlabel("Point No")
    plt.ylabel("P1 Win Probability (Smoothed)")
    plt.title(f"Match {match_id} Momentum Curve")
    plt.legend()
    plt.grid(True)

    # 检测势头反转点（简单：动量增减方向改变且幅度超过阈值）
    shifts = []
    mom = mdf["momentum_score"].values
    pts = mdf["point_no"].values

    for i in range(2, len(mom)):
        delta_prev = mom[i - 1] - mom[i - 2]
        delta_curr = mom[i] - mom[i - 1]

        # 从上升转为下降（局部峰值）
        if delta_prev > 0 and delta_curr <= 0 and abs(delta_prev) >= threshold:
            shifts.append(("peak", int(pts[i - 1]), mom[i - 1]))

        # 从下降转为上升（局部谷底）
        if delta_prev < 0 and delta_curr >= 0 and abs(delta_prev) >= threshold:
            shifts.append(("trough", int(pts[i - 1]), mom[i - 1]))

    # 在图上标记
    for stype, pno, mval in shifts:
        color = "red" if stype == "peak" else "green"
        plt.scatter(pno, mval, color=color)
        plt.text(pno, mval + 0.02, stype, fontsize=8, color=color, ha="center")

    out_png = f"momentum_match_{match_id}.png"
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()
    print(f"势头曲线已保存为图片：{out_png}")

    # 打印势头反转点
    print(f"\nMatch {match_id} 势头反转点（基于动量曲线）：")
    if not shifts:
        print("  未检测到显著的势头反转（阈值可适当调小）。")
    else:
        for stype, pno, mval in shifts:
            print(f"  - {stype} at point_no={pno}, momentum={mval:.3f}")

    return


# ============================
# 按局（game）预测胜负
# ============================
def evaluate_game_level_predictions(df):
    """
    使用逐分预测概率，按 (match_id, set_no, game_no) 聚合，
    以一局内平均概率 > 0.5 预测 P1 赢该局。
    """
    df = df[~df["p1_win_prob"].isna()].copy()
    if df.empty:
        print("没有逐分预测概率，无法进行按局评估。")
        return

    game_records = []

    for (mid, set_no, game_no), gdf in df.groupby(["match_id", "set_no", "game_no"]):
        gdf = gdf.sort_values("point_no")
        # 平均预测概率
        mean_prob = gdf["p1_win_prob"].mean()
        # 真实赢家：该局最后一分
        last_row = gdf.iloc[-1]
        actual_p1_win = int(last_row["p1_won"])  # 1 or 0
        actual_winner = 1 if actual_p1_win == 1 else 2
        # 预测
        pred_winner = 1 if mean_prob >= 0.5 else 2
        correct = int(pred_winner == actual_winner)

        game_records.append({
            "match_id": mid,
            "set_no": set_no,
            "game_no": game_no,
            "mean_prob": mean_prob,
            "actual_winner": actual_winner,
            "pred_winner": pred_winner,
            "correct": correct
        })

    gd = pd.DataFrame(game_records)
    if len(gd) == 0:
        print("没有有效局数据。")
        return

    acc = gd["correct"].mean()
    print(f"\n按局（game）预测整体准确率：{acc:.4f}  （共 {len(gd)} 局）")

    # 可选：打印前几局对比
    print("\n示例若干局的真实 vs 预测：")
    print(gd.head(10)[["match_id", "set_no", "game_no", "actual_winner", "pred_winner", "mean_prob"]])

    gd.to_csv("game_level_predictions.csv", index=False, encoding="utf-8-sig")
    print("按局预测结果已保存：game_level_predictions.csv")


# ============================
# 主流程
# ============================
def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    # 1. 读取原始逐分特征
    df = pd.read_csv("train_features.csv")

    # 2. 处理类别变量（serve_width, serve_depth, return_depth）
    cat_cols = ["serve_width", "serve_depth", "return_depth"]
    for col in cat_cols:
        df[col] = df[col].astype("category").cat.codes

    # 3. 标签：p1_won = (point_victor == 1)
    df["p1_won"] = (df["point_victor"] == 1).astype(int)

    # 4. 填补缺失值，统一为数值型
    df = df.fillna(0)
    for col in df.columns:
        if df[col].dtype == "object":
            df[col] = df[col].astype("category").cat.codes

    # 5. 特征列（注意：不包括 p1_won 和 point_victor）
    feature_cols = [c for c in df.columns if c not in ["p1_won", "point_victor"]]

    # 6. 按 match 划分 train / val
    matches = df["match_id"].unique()
    np.random.shuffle(matches)
    split_idx = int(len(matches) * 0.7)
    train_matches = matches[:split_idx]
    val_matches = matches[split_idx:]

    df_train = df[df["match_id"].isin(train_matches)].copy()
    df_val = df[df["match_id"].isin(val_matches)].copy()

    print(f"Train matches: {len(train_matches)}, Val matches: {len(val_matches)}")

    # 7. 构建序列数据
    X_train, y_train = build_sequences(df_train, SEQ_LEN, feature_cols, label_col="p1_won")
    X_val, y_val = build_sequences(df_val, SEQ_LEN, feature_cols, label_col="p1_won")

    print("X_train:", X_train.shape, "X_val:", X_val.shape)

    input_dim = X_train.shape[2]

    # 8. 训练 GRU 模型
    model = train_gru_model(X_train, y_train, X_val, y_val, input_dim, device)

    # 9. 用训练好的模型为所有逐分生成预测概率
    df_with_pred = add_point_predictions(df, model, feature_cols, SEQ_LEN, device)

    # 10. 选择一场比赛画势头曲线
    demo_match_id = df_with_pred["match_id"].iloc[0]
    print(f"\n将对 Match {demo_match_id} 进行势头分析（如需指定，可修改代码中的 demo_match_id）")
    analyze_momentum_for_match(df_with_pred, demo_match_id, window=MOMENTUM_WINDOW, threshold=MOMENTUM_THRESHOLD)

    # 11. 进行按局（game-level）预测评估
    evaluate_game_level_predictions(df_with_pred)


if __name__ == "__main__":
    main()
