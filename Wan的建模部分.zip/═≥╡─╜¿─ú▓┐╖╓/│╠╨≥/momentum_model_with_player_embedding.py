# -*- coding: utf-8 -*-
"""
Momentum GRU from raw Wimbledon data + Player Embedding + Momentum Curve

输入：2024_Wimbledon_featured_matches.csv（官方原始逐分数据）
功能：
1. 读取原始逐分数据 + 按 data dictionary 解析字段
2. 构造标签：p1_won（point_victor == 1）
3. 将 elapsed_time 转成秒数（elapsed_seconds）
4. 将类别字段（p1_score, p2_score, winner_shot_type, serve_width, serve_depth, return_depth）编码为整数
5. 基于 player1/player2 构造球员 embedding（player_id）
6. 构造 seq_len=20 的逐分时间序列（按 set_no, game_no, point_no 排序）
7. 训练 GRU + player embedding 模型预测 p1 下一分胜率
8. 为所有 point 生成 p1_win_prob，绘制某一场比赛的势头曲线（momentum curve）
9. 检测势头反转点（peak/trough）
10. 按局（game）聚合预测，评估 game-level 准确率
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt

# =========================
# 全局参数
# =========================
SEQ_LEN = 20
BATCH_SIZE = 64
EPOCHS = 15
MOMENTUM_WINDOW = 5
MOMENTUM_THRESHOLD = 0.05  # 势头反转阈值（可调）

RAW_FILE = "2024_Wimbledon_featured_matches.csv"


# =========================
# 1. 读取原始逐分数据
# =========================
def load_raw():
    df = pd.read_csv(RAW_FILE)

    print("原始数据形状：", df.shape)

    # 标签：字典里 point_victor = winner of the point (1=player1, 2=player2)
    df["p1_won"] = (df["point_victor"] == 1).astype(int)

    # elapsed_time: H:MM:SS → 转成总秒数
    df["elapsed_seconds"] = pd.to_timedelta(df["elapsed_time"]).dt.total_seconds()

    return df


# =========================
# 2. 建立球员 ID 映射（用于 embedding）
# =========================
def add_player_ids(df: pd.DataFrame):
    players = pd.unique(df[["player1", "player2"]].values.ravel())
    player2id = {name: idx for idx, name in enumerate(players)}
    id2player = {idx: name for name, idx in player2id.items()}

    df["p1_id"] = df["player1"].map(player2id)
    df["p2_id"] = df["player2"].map(player2id)

    print("球员数量：", len(player2id))
    return df, player2id, id2player


# =========================
# 3. 特征工程：编码类别变量
# =========================
def encode_categories(df: pd.DataFrame):
    """
    根据 data dictionary：
    - p1_score / p2_score：局内比分 (0,15,30,40,AD等) → category code
    - winner_shot_type：制胜分类型 → category code
    - serve_width：发球落点宽度 B/C/W 等 → category code
    - serve_depth：发球深度（CTL/NCTL）→ category code
    - return_depth：接发球深度（D/ND）→ category code
    """
    cat_cols = [
        "p1_score",
        "p2_score",
        "winner_shot_type",
        "serve_width",
        "serve_depth",
        "return_depth",
    ]

    for c in cat_cols:
        if c in df.columns:
            df[c] = df[c].astype(str).astype("category").cat.codes

    return df


# =========================
# 4. 构造序列
# =========================
def build_sequences(df, seq_len, feature_cols, label_col="p1_won"):
    """
    每场比赛按 (set_no, game_no, point_no) 排序，
    用前 seq_len 个点的特征预测当前点是否 p1 获胜。
    返回：
    - X: (N_seq, seq_len, D)
    - y: (N_seq,)
    - p1_ids, p2_ids: (N_seq,)
    - match_ids: (N_seq,)
    """
    X_list, y_list, p1_list, p2_list, mid_list = [], [], [], [], []

    for mid, mdf in df.groupby("match_id"):
        mdf = mdf.sort_values(["set_no", "game_no", "point_no"]).copy()

        X_vals = mdf[feature_cols].values
        y_vals = mdf[label_col].values
        p1_id = mdf["p1_id"].iloc[0]
        p2_id = mdf["p2_id"].iloc[0]

        if len(mdf) <= seq_len:
            continue

        for i in range(seq_len, len(mdf)):
            X_list.append(X_vals[i - seq_len:i])
            y_list.append(y_vals[i])
            p1_list.append(p1_id)
            p2_list.append(p2_id)
            mid_list.append(mid)

    X = np.array(X_list)
    y = np.array(y_list)
    p1_ids = np.array(p1_list)
    p2_ids = np.array(p2_list)
    mids = np.array(mid_list)

    print("构造序列完成：", X.shape, y.shape)
    return X, y, p1_ids, p2_ids, mids


# =========================
# 5. Dataset
# =========================
class TennisDataset(Dataset):
    def __init__(self, X, y, p1_ids, p2_ids):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)
        self.p1_ids = torch.tensor(p1_ids, dtype=torch.long)
        self.p2_ids = torch.tensor(p2_ids, dtype=torch.long)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return (
            self.X[idx],
            self.y[idx],
            self.p1_ids[idx],
            self.p2_ids[idx],
        )


# =========================
# 6. GRU + Player Embedding
# =========================
class GRUWithPlayer(nn.Module):
    def __init__(self, input_dim, num_players, emb_dim=32, hidden_dim=128):
        super().__init__()
        self.player_emb = nn.Embedding(num_players, emb_dim)

        self.gru = nn.GRU(
            input_dim + 2 * emb_dim,
            hidden_dim,
            num_layers=2,
            dropout=0.4,
            batch_first=True,
            bidirectional=True,
        )

        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, 1),
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, x, p1_ids, p2_ids):
        B, L, D = x.shape

        p1_e = self.player_emb(p1_ids)  # (B, emb_dim)
        p2_e = self.player_emb(p2_ids)  # (B, emb_dim)

        p1_e = p1_e.unsqueeze(1).repeat(1, L, 1)
        p2_e = p2_e.unsqueeze(1).repeat(1, L, 1)

        x = torch.cat([x, p1_e, p2_e], dim=-1)  # (B, L, D + 2*emb)

        out, _ = self.gru(x)
        out = out[:, -1, :]  # 取最后一个时间步
        out = self.fc(out)
        return self.sigmoid(out).squeeze(-1)


# =========================
# 7. 训练
# =========================
def train_gru_model(model, train_loader, val_loader, device):
    criterion = nn.BCELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4)

    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0
        for Xb, yb, p1b, p2b in train_loader:
            Xb, yb = Xb.to(device), yb.to(device)
            p1b, p2b = p1b.to(device), p2b.to(device)

            optimizer.zero_grad()
            preds = model(Xb, p1b, p2b)
            loss = criterion(preds, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(Xb)

        train_loss = total_loss / len(train_loader.dataset)

        # 验证
        model.eval()
        val_loss = 0
        correct = 0
        with torch.no_grad():
            for Xb, yb, p1b, p2b in val_loader:
                Xb, yb = Xb.to(device), yb.to(device)
                p1b, p2b = p1b.to(device), p2b.to(device)
                preds = model(Xb, p1b, p2b)
                loss = criterion(preds, yb)
                val_loss += loss.item() * len(Xb)
                preds_label = (preds >= 0.5).float()
                correct += (preds_label == yb).sum().item()

        val_loss /= len(val_loader.dataset)
        val_acc = correct / len(val_loader.dataset)
        print(f"[Epoch {epoch:02d}] Train {train_loss:.4f} | Val {val_loss:.4f} | Val Acc {val_acc:.4f}")

    torch.save(model.state_dict(), "momentum_gru_from_raw_player_emb.pt")
    print("模型保存为 momentum_gru_from_raw_player_emb.pt")
    return model


# =========================
# 8. 为每一分添加预测概率
# =========================
def add_point_predictions(df, model, feature_cols, seq_len, device):
    df = df.copy()
    df["p1_win_prob"] = np.nan

    model.eval()
    with torch.no_grad():
        for mid, mdf in df.groupby("match_id"):
            mdf = mdf.sort_values(["set_no", "game_no", "point_no"]).copy()
            X_vals = mdf[feature_cols].values
            p1_id = mdf["p1_id"].iloc[0]
            p2_id = mdf["p2_id"].iloc[0]

            probs = [np.nan] * len(mdf)

            if len(mdf) <= seq_len:
                df.loc[mdf.index, "p1_win_prob"] = probs
                continue

            for i in range(seq_len, len(mdf)):
                seq = X_vals[i - seq_len:i]
                seq_t = torch.tensor(seq, dtype=torch.float32, device=device).unsqueeze(0)
                p1_t = torch.tensor([p1_id], dtype=torch.long, device=device)
                p2_t = torch.tensor([p2_id], dtype=torch.long, device=device)

                p = model(seq_t, p1_t, p2_t).item()
                probs[i] = p

            df.loc[mdf.index, "p1_win_prob"] = probs

    return df


# =========================
# 9. 势头分析 + 曲线
# =========================
def analyze_momentum_for_match(df, match_id, window, threshold):
    mdf = df[df["match_id"] == match_id].sort_values(["set_no", "game_no", "point_no"]).copy()
    mdf = mdf[~mdf["p1_win_prob"].isna()]

    if mdf.empty:
        print(f"Match {match_id}: 没有可用的逐分预测概率。")
        return

    p1_name = mdf["player1"].iloc[0]
    p2_name = mdf["player2"].iloc[0]

    print(f"\n势头分析  Match {match_id}: {p1_name} vs {p2_name}")

    # 平滑势头
    mdf["momentum_score"] = mdf["p1_win_prob"].rolling(window, min_periods=1).mean()

    out_csv = f"momentum_match_{match_id}.csv"
    mdf.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print(f"逐分势头数据已保存：{out_csv}")

    # 绘图
    plt.figure(figsize=(10, 5))
    x = np.arange(len(mdf))
    plt.plot(x, mdf["momentum_score"], label=f"{p1_name} Momentum")
    plt.axhline(0.5, color="gray", linestyle="--", linewidth=1, label="50% baseline")
    plt.xlabel("Point index in match")
    plt.ylabel("Smoothed P1 Win Probability")
    plt.title(f"Momentum Curve: {p1_name} vs {p2_name}")
    plt.grid(True)

    # 势头反转点检测
    shifts = []
    mom = mdf["momentum_score"].values

    for i in range(2, len(mom)):
        dp_prev = mom[i - 1] - mom[i - 2]
        dp = mom[i] - mom[i - 1]

        # 上升 → 下降
        if dp_prev > 0 and dp <= 0 and abs(dp_prev) >= threshold:
            shifts.append(("peak", i - 1, mom[i - 1]))
        # 下降 → 上升
        if dp_prev < 0 and dp >= 0 and abs(dp_prev) >= threshold:
            shifts.append(("trough", i - 1, mom[i - 1]))

    for t, idx, val in shifts:
        color = "red" if t == "peak" else "green"
        plt.scatter(idx, val, color=color)
        plt.text(idx, val + 0.02, t, fontsize=8, color=color, ha="center")

    out_png = f"momentum_match_{match_id}.png"
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()
    print(f"势头曲线已保存：{out_png}")

    print("\n势头反转点：")
    if not shifts:
        print("  未检测到显著反转（可以调小 threshold 或加大平滑窗口）。")
    else:
        for t, idx, val in shifts:
            print(f"  - {t} at index={idx}, momentum={val:.3f}")


# =========================
# 10. 按局预测评估
# =========================
def evaluate_game_level_predictions(df):
    df = df[~df["p1_win_prob"].isna()].copy()
    if df.empty:
        print("没有逐分预测概率，无法进行按局评估。")
        return

    rows = []
    for (mid, set_no, game_no), gdf in df.groupby(["match_id", "set_no", "game_no"]):
        gdf = gdf.sort_values(["point_no"])
        mean_prob = gdf["p1_win_prob"].mean()

        last = gdf.iloc[-1]
        actual_p1_win = int(last["p1_won"])
        actual = 1 if actual_p1_win == 1 else 2
        pred = 1 if mean_prob >= 0.5 else 2
        correct = int(pred == actual)

        rows.append({
            "match_id": mid,
            "set_no": set_no,
            "game_no": game_no,
            "p1_name": last["player1"],
            "p2_name": last["player2"],
            "actual_winner": actual,
            "pred_winner": pred,
            "mean_prob": mean_prob,
            "correct": correct,
        })

    gd = pd.DataFrame(rows)
    acc = gd["correct"].mean()
    print(f"\n按局（game）预测准确率：{acc:.4f}  （共 {len(gd)} 局）")
    print("\n示例若干局：")
    print(gd.head(10))

    gd.to_csv("game_level_predictions_from_raw.csv", index=False, encoding="utf-8-sig")
    print("按局预测结果已保存为：game_level_predictions_from_raw.csv")


# =========================
# 11. 主程序
# =========================
def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    # 1) 读取原始逐分数据
    df = load_raw()

    # 2) 加球员 ID（embedding）
    df, player2id, id2player = add_player_ids(df)

    # 3) 编码类别字段（参考数据字典）
    df = encode_categories(df)

    # 4) 缺失处理
    df = df.fillna(0)

    # 5) 构造特征列：排除标识/标签/embedding 原字段
    exclude_cols = [
        "match_id",
        "player1",
        "player2",
        "elapsed_time",  # 原始字符串版
        "p1_won",
        "point_victor",
        "p1_id",
        "p2_id",
    ]
    feature_cols = [c for c in df.columns if c not in exclude_cols]

    print("特征列数量：", len(feature_cols))

    # 6) 按 match 划分 train/val
    mids = df["match_id"].unique()
    np.random.shuffle(mids)
    split = int(len(mids) * 0.7)
    train_mids = mids[:split]
    val_mids = mids[split:]

    df_train = df[df["match_id"].isin(train_mids)].copy()
    df_val = df[df["match_id"].isin(val_mids)].copy()

    print("Train matches:", len(train_mids), "Val matches:", len(val_mids))

    # 7) 构造序列
    X_train, y_train, p1_train, p2_train, _ = build_sequences(
        df_train, SEQ_LEN, feature_cols, label_col="p1_won"
    )
    X_val, y_val, p1_val, p2_val, _ = build_sequences(
        df_val, SEQ_LEN, feature_cols, label_col="p1_won"
    )

    print("X_train dtype:", X_train.dtype, "shape:", X_train.shape)

    train_loader = DataLoader(
        TennisDataset(X_train, y_train, p1_train, p2_train),
        batch_size=BATCH_SIZE,
        shuffle=True,
    )
    val_loader = DataLoader(
        TennisDataset(X_val, y_val, p1_val, p2_val),
        batch_size=BATCH_SIZE,
        shuffle=False,
    )

    # 8) 初始化并训练模型
    model = GRUWithPlayer(
        input_dim=X_train.shape[2],
        num_players=len(player2id),
        emb_dim=32,
        hidden_dim=128,
    ).to(device)

    model = train_gru_model(model, train_loader, val_loader, device)

    # 9) 逐分加预测概率
    df_pred = add_point_predictions(df, model, feature_cols, SEQ_LEN, device)

    # 10) 势头分析（选第一场比赛示例，你也可以指定别的 match_id）
    demo_mid = df_pred["match_id"].iloc[0]
    analyze_momentum_for_match(df_pred, demo_mid, MOMENTUM_WINDOW, MOMENTUM_THRESHOLD)

    # 11) 按局预测评估
    evaluate_game_level_predictions(df_pred)


if __name__ == "__main__":
    main()
