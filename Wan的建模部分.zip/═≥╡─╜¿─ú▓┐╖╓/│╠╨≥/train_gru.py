# -*- coding: utf-8 -*-
"""
GRU 逐分预测模型
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np

# ===================
# Dataset
# ===================
class TennisDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

# ===================
# GRU Model
# ===================
class GRUModel(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2, dropout=0.5):
        super().__init__()
        self.gru = nn.GRU(
            input_dim, hidden_dim,
            num_layers=num_layers,
            dropout=dropout,
            batch_first=True,
            bidirectional=True
        )
        self.norm = nn.LayerNorm(hidden_dim * 2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_dim, 1)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, h = self.gru(x)
        last_hidden = self.norm(out[:, -1, :])
        out = self.fc(last_hidden)
        return self.sigmoid(out).squeeze(-1)

# ===================
# Train & Eval
# ===================
def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0
    for X, y in loader:
        X, y = X.to(device), y.to(device)
        optimizer.zero_grad()
        preds = model(X)
        loss = criterion(preds, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * len(X)
    return total_loss / len(loader.dataset)

def eval_epoch(model, loader, criterion, device):
    model.eval()
    total_loss = 0
    correct = 0
    with torch.no_grad():
        for X, y in loader:
            X, y = X.to(device), y.to(device)
            preds = model(X)
            loss = criterion(preds, y)
            total_loss += loss.item() * len(X)
            pred_label = (preds >= 0.5).float()
            correct += (pred_label == y).sum().item()
    return total_loss / len(loader.dataset), correct / len(loader.dataset)

# ===================
# Main
# ===================
def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device)

    X_train = np.load("X_train_seq.npy", allow_pickle=True)
    y_train = np.load("y_train_seq.npy", allow_pickle=True)
    X_test = np.load("X_test_seq.npy", allow_pickle=True)
    y_test = np.load("y_test_seq.npy", allow_pickle=True)

    train_loader = DataLoader(TennisDataset(X_train, y_train), batch_size=64, shuffle=True)
    test_loader = DataLoader(TennisDataset(X_test, y_test), batch_size=64, shuffle=False)

    input_dim = X_train.shape[2]
    model = GRUModel(input_dim).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    criterion = nn.BCELoss()

    best_val = 1e9
    patience = 6
    counter = 0
    best_state = None

    for epoch in range(1, 50+1):
        tr_loss = train_one_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = eval_epoch(model, test_loader, criterion, device)

        print(f"[Epoch {epoch}] Train {tr_loss:.4f} | Val {val_loss:.4f} | Acc {val_acc:.4f}")

        if val_loss < best_val:
            best_val = val_loss
            counter = 0
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
        else:
            counter += 1
            if counter >= patience:
                print("Early stopping!")
                break

    model.load_state_dict(best_state)
    torch.save(model.state_dict(), "model_gru.pt")
    print("模型已保存为 model_gru.pt")

if __name__ == "__main__":
    main()
