import numpy as np
import pandas as pd

# ==========================
# 1. 7:3划分训练集和测试集
# ==========================

# 读取之前构建好的特征
df_features = pd.read_csv("wimbledon_processed_features.csv")

# 确保标签严格为 0/1，无 NaN——
df_features["point_victor"] = df_features["point_victor"].map({1: 1, 2: 0})
df_features["point_victor"] = df_features["point_victor"].fillna(0).astype(int)
print("标签唯一值:", df_features["point_victor"].unique())

# 获取所有比赛ID
match_ids = df_features["match_id"].unique()

# 7:3 划分训练集和测试集
n_train = int(len(match_ids) * 0.7)
train_ids = match_ids[:n_train]
test_ids = match_ids[n_train:]

train_df = df_features[df_features["match_id"].isin(train_ids)].reset_index(drop=True)
test_df  = df_features[df_features["match_id"].isin(test_ids)].reset_index(drop=True)

print("Train matches:", len(train_ids))
print("Test matches:", len(test_ids))
print("Train data shape:", train_df.shape)
print("Test data shape:",  test_df.shape)


# =======================================
# 2. 加载 X_all, y_all，并按 match_id 拆分
# =======================================
y_all = df_features["point_victor"].values.astype(np.int64)
np.save("y_all.npy", y_all)

# 同时加载 X_all
X_all = np.load("X_all.npy", allow_pickle=True)

match_series = df_features["match_id"].values

train_mask = np.isin(match_series, train_ids)
test_mask  = np.isin(match_series, test_ids)

X_train_full = X_all[train_mask]
y_train_full = y_all[train_mask]

X_test_full = X_all[test_mask]
y_test_full = y_all[test_mask]

print("X_train_full:", X_train_full.shape)
print("X_test_full:",  X_test_full.shape)


# =======================================
# 3. 构造 seq_len=20 的 LSTM 输入
# =======================================

def build_lstm_sequences(df, X_all, y_all, match_ids, seq_len=20):
    X_seqs, y_seqs = [], []

    for mid in match_ids:
        idx = df[df["match_id"] == mid].index.values
        X_m = X_all[idx]
        y_m = y_all[idx]

        for i in range(len(X_m) - seq_len):
            X_seqs.append(X_m[i:i+seq_len])
            y_seqs.append(y_m[i+seq_len])

    return np.array(X_seqs), np.array(y_seqs)


SEQ_LEN = 20

X_train_seq, y_train_seq = build_lstm_sequences(
    df_features, X_all, y_all, train_ids, seq_len=SEQ_LEN
)

X_test_seq, y_test_seq = build_lstm_sequences(
    df_features, X_all, y_all, test_ids, seq_len=SEQ_LEN
)


print("LSTM 训练集形状:", X_train_seq.shape)
print("LSTM 测试集形状:", X_test_seq.shape)


# ==========================
# 4. 保存行级特征 + 数值化集 + 序列
# ==========================
train_df.to_csv("train_features.csv", index=False, encoding="utf-8-sig")
test_df.to_csv("test_features.csv", index=False, encoding="utf-8-sig")

np.save("X_train_full.npy", X_train_full)
np.save("y_train_full.npy", y_train_full)

np.save("X_test_full.npy", X_test_full)
np.save("y_test_full.npy", y_test_full)

np.save("X_train_seq.npy", X_train_seq)
np.save("y_train_seq.npy", y_train_seq)
np.save("X_test_seq.npy", X_test_seq)
np.save("y_test_seq.npy", y_test_seq)

print("全部保存完成！")
