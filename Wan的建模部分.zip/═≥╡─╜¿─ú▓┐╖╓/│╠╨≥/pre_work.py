# -*- coding: utf-8 -*-
"""
Wimbledon 网球逐分数据
数据预处理 & 特征工程完整脚本

功能：
1. 读取所有比赛数据
2. 构造上下文特征、即时回合特征、关键分特征、历史动量特征
3. 为每一行加入球员文本 embedding（多源数据：结构化 + 文本）[选择性]
4. 生成可用于 LSTM/GRU/Transformer 的数值化特征矩阵 X_all, y_all
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline




# ==========================
# 1. 基本参数设置
# ==========================
DATA_PATH = "D:/南京大学/信管期末/大三上/大数据/final_project/data/2024_Wimbledon_featured_matches.csv"  # 修改成你自己的路径
ROLL_WINDOW = 10   # 历史动量窗口长度（最近 N 分）



# ==========================
# 2. 读取 & 排序
# ==========================
print("读取数据...")
df = pd.read_csv(DATA_PATH)

print("原始数据规模:", df.shape)
# 按比赛 & 比分顺序排序，保证时间顺序正确
df = df.sort_values(by=["match_id", "set_no", "game_no", "point_no"]).reset_index(drop=True)


# ==========================
# 3. 构造比赛上下文特征
# ==========================
print("构造比赛上下文特征...")

# 盘/局差
df["set_diff"] = df["p1_sets"] - df["p2_sets"]
df["game_diff"] = df["p1_games"] - df["p2_games"]

# 也可以保留原始的 set_no / game_no / point_no 等作为位置特征
# （这些本身就是数值，不需要额外处理）


# ==========================
# 4. 构造即时回合特征（不需要额外计算的直接保留）
# ==========================
print("构造即时回合特征...")

# 为了后续方便，可以先填充一些可能的 NaN（例如部分行缺失某些统计）
instant_numeric_cols = [
    "speed_mph",
    "rally_count",
    "p1_ace", "p2_ace",
    "p1_double_fault", "p2_double_fault",
    "p1_unf_err", "p2_unf_err",
    "p1_winner", "p2_winner",
    "p1_net_pt", "p2_net_pt",
    "p1_net_pt_won", "p2_net_pt_won",
]

for col in instant_numeric_cols:
    if col in df.columns:
        df[col] = df[col].fillna(0)


# ==========================
# 5. 构造关键分特征
# ==========================
print("构造关键分特征...")

key_cols = [
    "p1_break_pt", "p2_break_pt",
    "p1_break_pt_won", "p2_break_pt_won",
    "p1_break_pt_missed", "p2_break_pt_missed",
]

for col in key_cols:
    if col in df.columns:
        df[col] = df[col].fillna(0)


# ==========================
# 6. 历史动量特征（按 match_id 分组 rolling）
# ==========================
print("构造历史动量特征（rolling）...")

def add_rolling_features(g: pd.DataFrame, window: int) -> pd.DataFrame:
    """对单场比赛数据 g 按时间顺序添加 rolling 特征"""
    g = g.copy()

    # 最近 N 分 p1 胜率（point_victor=1 代表 p1 赢）
    g["p1_recent_win_rate"] = (
        g["point_victor"]
        .rolling(window=window, min_periods=1)
        .mean()
    )

    # 最近 N 分平均回合长度
    g["recent_avg_rally"] = (
        g["rally_count"]
        .rolling(window=window, min_periods=1)
        .mean()
    )

    # 最近 N 分 p1 / p2 非受迫失误率（用 rolling mean）
    g["p1_recent_ufe_rate"] = (
        g["p1_unf_err"]
        .rolling(window=window, min_periods=1)
        .mean()
    )
    g["p2_recent_ufe_rate"] = (
        g["p2_unf_err"]
        .rolling(window=window, min_periods=1)
        .mean()
    )

    # 最近 N 分 p1/p2 上网成功率（上网得分 / 上网尝试）
    p1_net_sum = g["p1_net_pt"].rolling(window=window, min_periods=1).sum()
    p1_net_won_sum = g["p1_net_pt_won"].rolling(window=window, min_periods=1).sum()
    g["p1_recent_net_success"] = p1_net_won_sum / (p1_net_sum + 1e-6)

    p2_net_sum = g["p2_net_pt"].rolling(window=window, min_periods=1).sum()
    p2_net_won_sum = g["p2_net_pt_won"].rolling(window=window, min_periods=1).sum()
    g["p2_recent_net_success"] = p2_net_won_sum / (p2_net_sum + 1e-6)

    return g

df = df.groupby("match_id", group_keys=False).apply(
    lambda g: add_rolling_features(g, window=ROLL_WINDOW)
)


# ==========================
# 8. 整理最后要用的特征列
# ==========================
print("整理最终特征列...")

# （1）比赛上下文
context_cols = [
    "set_no", "game_no", "point_no",
    "p1_sets", "p2_sets",
    "p1_games", "p2_games",
    "set_diff", "game_diff",
]

# （2）即时回合特征
instant_numeric_cols = [
    "speed_mph",
    "rally_count",
    "p1_ace", "p2_ace",
    "p1_double_fault", "p2_double_fault",
    "p1_unf_err", "p2_unf_err",
    "p1_winner", "p2_winner",
    "p1_net_pt", "p2_net_pt",
    "p1_net_pt_won", "p2_net_pt_won",
]

# （3）关键分特征
key_cols = [
    "p1_break_pt", "p2_break_pt",
    "p1_break_pt_won", "p2_break_pt_won",
    "p1_break_pt_missed", "p2_break_pt_missed",
]

# （4）历史动量特征
rolling_cols = [
    "p1_recent_win_rate",
    "recent_avg_rally",
    "p1_recent_ufe_rate", "p2_recent_ufe_rate",
    "p1_recent_net_success", "p2_recent_net_success",
]

# （5）类别特征（做 One-Hot）
categorical_cols = ["serve_width", "serve_depth", "return_depth", "server", "serve_no"]

# （6）embedding 特征列
embedding_cols = [col for col in df.columns if col.startswith("p1_emb_") or col.startswith("p2_emb_")]

# 标签（下一步建模用）
label_col = "point_victor"

# 选取所有需要的列
all_feature_cols = (
    context_cols
    + instant_numeric_cols
    + key_cols
    + rolling_cols
    + categorical_cols
    + embedding_cols
)

df_features = df[["match_id"] + all_feature_cols + [label_col]].copy()
print("特征 DataFrame 维度:", df_features.shape)


# ==========================
# 9. 数值化：One-Hot + 标准化（为后续建模准备 X_all, y_all）
# ==========================
print("开始数值化特征...")

numeric_cols = context_cols + instant_numeric_cols + key_cols + rolling_cols + embedding_cols

# ColumnTransformer：
# - 对类别特征做 One-Hot
# - 对数值特征做标准化
preprocess = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols),
        ("num", StandardScaler(), numeric_cols),
    ]
)

# 注意：严格来说应该在训练集上 fit，再在测试集上 transform。
# 这里先对全体数据 fit_transform，方便你调试和查看结果。
X_all = preprocess.fit_transform(df_features[all_feature_cols])
y_all = df_features[label_col].values

print("X_all 维度:", X_all.shape)
print("y_all 维度:", y_all.shape)

# ==========================
# 10. 可选：保存结果到本地文件
# ==========================
SAVE_FEATURE_DF = True
SAVE_NUMPY = True

if SAVE_FEATURE_DF:
    out_csv = "wimbledon_processed_features.csv"
    df_features.to_csv(out_csv, index=False, encoding="utf-8-sig")
    print(f"已保存特征 DataFrame 到 {out_csv}")

if SAVE_NUMPY:
    np.save("X_all.npy", X_all)
    np.save("y_all.npy", y_all)
    print("已保存 X_all.npy, y_all.npy")
    
print("✅ 数据预处理 & 特征工程 完成。")
