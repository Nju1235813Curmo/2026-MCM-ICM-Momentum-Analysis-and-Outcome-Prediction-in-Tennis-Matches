# -*- coding: utf-8 -*-
"""
LSTM 网球逐分胜负预测
可直接运行的完整 PyTorch 训练代码
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np


# ==========================================================
# 1. Dataset 定义
# ==========================================================
class TennisDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ==========================================================
# 2. LSTM 模型定义
# ==========================================================
class LSTMPointPredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2, dropout=0.3):
        super().__init__()
        self.lstm = nn.LSTM(
            input_dim,
            hidden_dim,
            num_layers=num_layers,
            dropout=dropout,
            batch_first=True
        )
        self.fc = nn.Linear(hidden_dim, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, (hn, cn) = self.lstm(x)
        last_h = hn[-1]        # (batch, hidden_dim)
        logits = self.fc(last_h)
        return self.sigmoid(logits).squeeze(-1)


# ==========================================================
# 3. 训练步骤
# ==========================================================
def train_one_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0

    for X_batch, y_batch in loader:
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)

        optimizer.zero_grad()
        preds = model(X_batch)

        loss = criterion(preds, y_batch)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * X_batch.size(0)

    return total_loss / len(loader.dataset)


# ==========================================================
# 4. 验证步骤
# ==========================================================
def evaluate(model, loader, criterion, device):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)

            preds = model(X_batch)
            loss = criterion(preds, y_batch)

            total_loss += loss.item() * X_batch.size(0)

            pred_labels = (preds >= 0.5).float()
            correct += (pred_labels == y_batch).sum().item()
            total += len(y_batch)

    acc = correct / total
    return total_loss / total, acc


# ==========================================================
# 5. 主流程：加载数据 + 训练 + 评估
# ==========================================================
def main():

    # -------------------------
    # 超参数
    # -------------------------
    batch_size = 64
    hidden_dim = 128
    num_layers = 2
    dropout = 0.3
    lr = 1e-3
    epochs = 20

    # -------------------------
    # 设备
    # -------------------------
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    # -------------------------
    # 加载序列数据
    # -------------------------
    X_train = np.load("X_train_seq.npy", allow_pickle=True)
    y_train = np.load("y_train_seq.npy", allow_pickle=True)
    X_test  = np.load("X_test_seq.npy", allow_pickle=True)
    y_test  = np.load("y_test_seq.npy", allow_pickle=True)


    print("训练数据维度:", X_train.shape)
    print("测试数据维度:", X_test.shape)


    # -------------------------
    # Dataset + DataLoader
    # -------------------------
    train_dataset = TennisDataset(X_train, y_train)
    test_dataset  = TennisDataset(X_test, y_test)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader  = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)


    # -------------------------
    # 模型初始化
    # -------------------------
    input_dim = X_train.shape[2]  # feature_dim
    model = LSTMPointPredictor(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout
    ).to(device)

    criterion = nn.BCELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    print("开始训练...\n")

    # -------------------------
    # 训练循环
    # -------------------------
    for epoch in range(1, epochs + 1):
        train_loss = train_one_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = evaluate(model, test_loader, criterion, device)

        print(f"Epoch {epoch:02d}/{epochs} | "
              f"Train Loss: {train_loss:.4f} | "
              f"Val Loss: {val_loss:.4f} | "
              f"Val Acc: {val_acc:.4f}")

    print("\n训练结束。")

    # -------------------------
    # 保存模型
    # -------------------------
    torch.save(model.state_dict(), "lstm_model.pt")
    print("已保存模型到 lstm_model.pt")


if __name__ == "__main__":
    main()
