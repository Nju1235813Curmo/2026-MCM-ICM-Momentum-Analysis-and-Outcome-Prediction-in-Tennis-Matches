# -*- coding: utf-8 -*-
"""
一次性评估三个模型性能（MAE、RMSE、F1、AUC）
BiLSTM（优化版）、GRU、Transformer_v2
"""

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error,
    f1_score, roc_auc_score
)

# ================================
# 1. 统一加载测试数据
# ================================
X_test = np.load("X_test_seq.npy", allow_pickle=True)
y_test = np.load("y_test_seq.npy", allow_pickle=True)

X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_true = y_test


# ================================
# 2. 定义三个模型，与训练时一致
# ================================

# ---- BiLSTM ----
class ImprovedLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2, dropout=0.5):
        super().__init__()
        self.lstm = nn.LSTM(
            input_dim, hidden_dim, num_layers=num_layers,
            batch_first=True, dropout=dropout, bidirectional=True
        )
        self.norm = nn.LayerNorm(hidden_dim * 2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_dim, 1)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.norm(out[:, -1, :])
        out = self.fc(out)
        return self.sigmoid(out).squeeze(-1)


# ---- GRU ----
class GRUModel(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2, dropout=0.5):
        super().__init__()
        self.gru = nn.GRU(
            input_dim, hidden_dim,
            num_layers=num_layers, dropout=dropout,
            batch_first=True, bidirectional=True
        )
        self.norm = nn.LayerNorm(hidden_dim * 2)
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_dim, 1)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        out, _ = self.gru(x)
        out = self.norm(out[:, -1, :])
        out = self.fc(out)
        return self.sigmoid(out).squeeze(-1)


# ---- Transformer_v2 ----
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=50):
        super().__init__()

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))

        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        self.pe = pe.unsqueeze(0)  # shape = (1, max_len, d_model)

    def forward(self, x):
        seq_len = x.size(1)
        return x + self.pe[:, :seq_len, :].to(x.device)



class TransformerPredictor(nn.Module):
    def __init__(self, input_dim, d_model=64, nhead=4, num_layers=1, dropout=0.2):
        super().__init__()

        self.input_proj = nn.Linear(input_dim, d_model)
        self.input_norm = nn.LayerNorm(d_model)
        self.pos_encoding = PositionalEncoding(d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=128,
            dropout=dropout,
            batch_first=True
        )

        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=num_layers
        )

        self.norm = nn.LayerNorm(d_model)

        self.fc = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model // 2, 1),
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.input_proj(x)
        x = self.input_norm(x)
        x = self.pos_encoding(x)
        x = self.encoder(x)
        x = self.norm(x)

        # mean pooling
        x = x.mean(dim=1)

        out = self.fc(x)
        return self.sigmoid(out).squeeze(-1)

# ================================
# 3. 通用评估函数
# ================================
def evaluate_model(model, name):
    model.eval()
    with torch.no_grad():
        preds_prob = model(X_test_tensor.to(device)).cpu().numpy()

    preds_label = (preds_prob >= 0.5).astype(int)

    mae = mean_absolute_error(y_true, preds_prob)
    rmse = np.sqrt(mean_squared_error(y_true, preds_prob))
    f1 = f1_score(y_true, preds_label)

    try:
        auc = roc_auc_score(y_true, preds_prob)
    except:
        auc = None

    return {
        "model": name,
        "MAE": mae,
        "RMSE": rmse,
        "F1": f1,
        "AUC": auc
    }


# ================================
# 4. 加载模型并评估
# ================================
device = "cuda" if torch.cuda.is_available() else "cpu"
input_dim = X_test.shape[2]

# BiLSTM
lstm = ImprovedLSTM(input_dim).to(device)
lstm.load_state_dict(torch.load("model_lstm_optimized.pt", map_location=device))

# GRU
gru = GRUModel(input_dim).to(device)
gru.load_state_dict(torch.load("model_gru.pt", map_location=device))

# Transformer_v2
trans = TransformerPredictor(input_dim).to(device)
trans.load_state_dict(torch.load("model_transformer_v2.pt", map_location=device))


results = []
results.append(evaluate_model(lstm, "BiLSTM"))
results.append(evaluate_model(gru, "GRU"))
results.append(evaluate_model(trans, "Transformer_v2"))


# ================================
# 5. 输出结果表
# ================================
print("\n=== 模型对比结果 ===")
for r in results:
    print(f"\n模型：{r['model']}")
    print(f"MAE:  {r['MAE']:.4f}")
    print(f"RMSE: {r['RMSE']:.4f}")
    print(f"F1:   {r['F1']:.4f}")
    print(f"AUC:  {r['AUC']:.4f}" if r["AUC"] else "AUC: 无法计算")

print("\n=== 总表格 ===")
print("Model\tMAE\tRMSE\tF1\tAUC")
for r in results:
    print(f"{r['model']}\t{r['MAE']:.4f}\t{r['RMSE']:.4f}\t{r['F1']:.4f}\t{(r['AUC'] if r['AUC'] else 0):.4f}")
