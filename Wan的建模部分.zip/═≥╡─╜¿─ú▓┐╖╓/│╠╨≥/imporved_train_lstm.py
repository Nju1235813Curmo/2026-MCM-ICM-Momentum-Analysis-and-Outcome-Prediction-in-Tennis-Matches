# -*- coding: utf-8 -*-
"""
高性能 LSTM 网球逐分预测模型（PyTorch）
含：
- Bidirectional LSTM
- LayerNorm
- Dropout 强正则化
- EarlyStopping
- ReduceLROnPlateau
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np
import os


# ==========================================================
# Dataset
# ==========================================================
class TennisDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ==========================================================
# 改进后的 LSTM 模型
# ==========================================================
class ImprovedLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, num_layers=2, dropout=0.5):
        super().__init__()

        self.lstm = nn.LSTM(
            input_dim,
            hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout,
            bidirectional=True
        )

        # LayerNorm 稳定训练
        self.norm = nn.LayerNorm(hidden_dim * 2)

        # Dense block（提升表达能力）
        self.fc = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(hidden_dim, 1)
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        lstm_out, (hn, cn) = self.lstm(x)
        last_hidden = lstm_out[:, -1, :]  # 双向：维度=hidden_dim*2
        last_hidden = self.norm(last_hidden)
        out = self.fc(last_hidden)
        return self.sigmoid(out).squeeze(-1)


# ==========================================================
# Early Stopping
# ==========================================================
class EarlyStopping:
    def __init__(self, patience=5, min_delta=0):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
        self.best_state_dict = None

    def step(self, val_loss, model):
        if self.best_loss is None or val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
            self.best_state_dict = {k: v.cpu() for k, v in model.state_dict().items()}
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True


# ==========================================================
# Train / Eval
# ==========================================================
def train_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0

    for X_batch, y_batch in loader:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)

        optimizer.zero_grad()
        preds = model(X_batch)
        loss = criterion(preds, y_batch)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * len(X_batch)

    return total_loss / len(loader.dataset)


def eval_epoch(model, loader, criterion, device):
    model.eval()
    total_loss = 0
    correct = 0

    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            preds = model(X_batch)
            loss = criterion(preds, y_batch)
            total_loss += loss.item() * len(X_batch)
            pred_labels = (preds >= 0.5).float()
            correct += (pred_labels == y_batch).sum().item()

    acc = correct / len(loader.dataset)
    return total_loss / len(loader.dataset), acc


# ==========================================================
# Main Training
# ==========================================================
def main():

    # 超参数
    batch_size = 64
    hidden_dim = 128
    num_layers = 2
    dropout = 0.5
    lr = 3e-4
    epochs = 50

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Using device:", device)

    # 加载数据
    X_train = np.load("X_train_seq.npy", allow_pickle=True)
    y_train = np.load("y_train_seq.npy", allow_pickle=True)
    X_test  = np.load("X_test_seq.npy", allow_pickle=True)
    y_test  = np.load("y_test_seq.npy", allow_pickle=True)

    print("Train shape:", X_train.shape)
    print("Test shape:", X_test.shape)

    # Dataset
    train_loader = DataLoader(TennisDataset(X_train, y_train), batch_size=batch_size, shuffle=True)
    test_loader  = DataLoader(TennisDataset(X_test, y_test), batch_size=batch_size, shuffle=False)

    input_dim = X_train.shape[2]

    # 初始化模型
    model = ImprovedLSTM(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout
    ).to(device)

    criterion = nn.BCELoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)

    # 学习率调度器
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=2
    )

    early_stopping = EarlyStopping(patience=7)

    # ================================
    # 训练循环
    # ================================
    for epoch in range(1, epochs + 1):

        train_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = eval_epoch(model, test_loader, criterion, device)

        scheduler.step(val_loss)
        early_stopping.step(val_loss, model)

        print(f"[Epoch {epoch:02d}] "
              f"Train Loss: {train_loss:.4f} | "
              f"Val Loss: {val_loss:.4f} | "
              f"Val Acc: {val_acc:.4f}")

        if early_stopping.early_stop:
            print("Early stopping triggered!")
            break

    # 载入早停时最优参数
    model.load_state_dict(early_stopping.best_state_dict)

    # 保存
    torch.save(model.state_dict(), "model_lstm_optimized.pt")
    print("模型已保存到 model_lstm_optimized.pt")


if __name__ == "__main__":
    main()

