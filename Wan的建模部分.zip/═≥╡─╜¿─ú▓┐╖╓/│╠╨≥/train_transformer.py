# -*- coding: utf-8 -*-
"""
 改进版 Transformer 模型
针对 seq_len=20，小数据集优化后的版本。
具有更好稳定性和收敛能力。
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import numpy as np


# ============================
# Dataset
# ============================
class TennisDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


# ============================
# Positional Encoding
# ============================
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=50):
        super().__init__()

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))

        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)

        self.pe = pe.unsqueeze(0)  # shape = (1, max_len, d_model)

    def forward(self, x):
        seq_len = x.size(1)
        return x + self.pe[:, :seq_len, :].to(x.device)


# ============================
# Transformer_v2 Model
# ============================
class TransformerPredictor(nn.Module):
    def __init__(self, input_dim, d_model=64, nhead=4, num_layers=1, dropout=0.2):
        super().__init__()

        self.input_proj = nn.Linear(input_dim, d_model)
        self.input_norm = nn.LayerNorm(d_model)
        self.pos_encoding = PositionalEncoding(d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=128,
            dropout=dropout,
            batch_first=True
        )

        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=num_layers
        )

        self.norm = nn.LayerNorm(d_model)

        self.fc = nn.Sequential(
            nn.Linear(d_model, d_model // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model // 2, 1),
        )

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.input_proj(x)
        x = self.input_norm(x)
        x = self.pos_encoding(x)
        x = self.encoder(x)
        x = self.norm(x)

        # mean pooling
        x = x.mean(dim=1)

        out = self.fc(x)
        return self.sigmoid(out).squeeze(-1)


# ============================
# Training & Evaluation
# ============================
def train_epoch(model, loader, optimizer, criterion, device):
    model.train()
    total_loss = 0

    for X_batch, y_batch in loader:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)

        optimizer.zero_grad()
        preds = model(X_batch)
        loss = criterion(preds, y_batch)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        total_loss += loss.item() * len(X_batch)

    return total_loss / len(loader.dataset)


def eval_epoch(model, loader, criterion, device):
    model.eval()
    total_loss = 0
    correct = 0

    with torch.no_grad():
        for X_batch, y_batch in loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            preds = model(X_batch)
            loss = criterion(preds, y_batch)

            total_loss += loss.item() * len(X_batch)

            pred_label = (preds >= 0.5).float()
            correct += (pred_label == y_batch).sum().item()

    return total_loss / len(loader.dataset), correct / len(loader.dataset)


# ============================
# Main
# ============================
def main():

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("Device:", device)

    # Load LSTM sequences
    X_train = np.load("X_train_seq.npy", allow_pickle=True)
    y_train = np.load("y_train_seq.npy", allow_pickle=True)
    X_test = np.load("X_test_seq.npy", allow_pickle=True)
    y_test = np.load("y_test_seq.npy", allow_pickle=True)

    train_loader = DataLoader(TennisDataset(X_train, y_train), batch_size=32, shuffle=True)
    test_loader = DataLoader(TennisDataset(X_test, y_test), batch_size=32, shuffle=False)

    input_dim = X_train.shape[2]

    # Initialize Transformer_v2
    model = TransformerPredictor(
        input_dim=input_dim,
        d_model=64,
        nhead=4,
        num_layers=1,
        dropout=0.2
    ).to(device)

    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=5e-4)
    criterion = nn.BCELoss()

    best_val = 1e9
    counter = 0
    patience = 8
    best_state = None

    for epoch in range(1, 60 + 1):
        tr_loss = train_epoch(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = eval_epoch(model, test_loader, criterion, device)

        print(f"[Epoch {epoch}] Train {tr_loss:.4f} | Val {val_loss:.4f} | Acc {val_acc:.4f}")

        if val_loss < best_val:
            best_val = val_loss
            best_state = {k: v.cpu() for k, v in model.state_dict().items()}
            counter = 0
        else:
            counter += 1
            if counter >= patience:
                print("Early stopping!")
                break

    model.load_state_dict(best_state)
    torch.save(model.state_dict(), "model_transformer_v2.pt")
    print("模型已保存为 model_transformer_v2.pt")


if __name__ == "__main__":
    main()
